# SquadUITweaks
A mod for Rimworld.

A few minor tweaks to the UI when selecting groups:
- shows weapon range when the mouse is over the "Attack" button
- shows the weapon types that are equipped
-- clicking the weapon allows for assigning targets to all pawns with that weapon

All of the code is basically vanilla Rimworld, I just linked various bits up. Hopefully this or something along these lines will be incorporated into [1.0]
