﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace SquadUITweaks
{
    public class Mod : Verse.Mod
    {
        public Mod(
            ModContentPack content) : base(content) { }
    }
}
